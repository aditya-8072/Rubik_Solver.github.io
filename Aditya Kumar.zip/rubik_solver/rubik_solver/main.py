from cube import Cube
from visualize import run_visualizer

if __name__ == '__main__':
    cube = Cube()
    run_visualizer(cube)